<?php

namespace PackageOnly_53798 {
	class MyClass {
		public $prop = "MyProp!\n";
	}
}


namespace FileOnly_65379 {
	class Baz {
		function hello(): void {
			echo "Yo Dawg!\n";
		}
	}
}